# -*- coding: utf-8 -*-
"""
Created on Mon Feb 17 21:35:18 2020

@author: Yang Xu
"""

import numpy as np
#from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.layers import Conv2D, MaxPooling2D
from tensorflow.keras.optimizers import SGD

##example1
data=np.array([[1,2,3,4,5],[5,4,3,2,1],[1,2,3,4,5],[5,4,3,2,1],[1,2,3,4,5]])
data = data.astype(float)
data=data.reshape(5,5,1)
y=np.zeros((1,1))

model = Sequential()
model.add(Conv2D(1, (3, 3), activation='sigmoid', input_shape=(5, 5, 1)))

model.add(Flatten())
model.add(Dense(1, activation='sigmoid'))

sgd = SGD(lr=0.5)
model.compile(loss='binary_crossentropy', optimizer=sgd)
model.fit(data.reshape(1,5,5,1),y,epochs=1)
outputs = model.predict(data.reshape(1,5,5,1))

##example2
data=np.array([[1,2,3,4,5],[5,4,3,2,1],[1,2,3,4,5],[5,4,3,2,1],[1,2,3,4,5]])
data = data.astype(float)
data=data.reshape(5,5,1)
y=np.zeros((1,1))

model = Sequential()
model.add(Conv2D(1, (3, 3), activation='sigmoid', input_shape=(5, 5, 1)))
model.add(Conv2D(1, (3, 3), activation='sigmoid'))
model.add(Flatten())
model.add(Dense(1, activation='sigmoid'))

sgd = SGD(lr=0.5)
model.compile(loss='binary_crossentropy', optimizer=sgd)
model.fit(data.reshape(1,5,5,1),y,epochs=1)
outputs = model.predict(data.reshape(1,5,5,1))

##example3
data=np.array([[1,2,3,4,5,6],[6,5,4,3,2,1],[1,2,3,4,5,6],
               [6,5,4,3,2,1],[1,2,3,4,5,6],[6,5,4,3,2,1]])
data = data.astype(float)          
data=data.reshape(6,6,1)
y=np.zeros((1,1))

model = Sequential()
model.add(Conv2D(1, (3, 3), activation='sigmoid', input_shape=(6, 6, 1)))
model.add(MaxPooling2D(pool_size=2))
model.add(Flatten())
model.add(Dense(1, activation='sigmoid'))

sgd = SGD(lr=0.5)
model.compile(loss='binary_crossentropy', optimizer=sgd)
model.fit(data.reshape(1,6,6,1),y,epochs=1)
outputs = model.predict(data.reshape(1,6,6,1))